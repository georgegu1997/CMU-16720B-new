from alignChannels import alignChannels
# Problem 1: Image Alignment

# 1. Load images (all 3 channels)
red = None
green = None
blue = None

# 2. Find best alignment
rgbResult = alignChannels(red, green, blue)

# 3. save result to rgb_output.jpg (IN THE "results" FOLDER)
